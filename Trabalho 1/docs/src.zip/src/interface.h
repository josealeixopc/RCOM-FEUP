#pragma once

#include "utils.h"

int clearfunction();

int startmenu();

int baudarecheck();

int selectPort();

int selectMaxSize();

int selectTimeout();

int selectAttempts();

void getfilename(char *filenamevar);

