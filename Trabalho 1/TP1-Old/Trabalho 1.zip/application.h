#include "link.h"

#define FILE_SIZE 1
#define NAME_SIZE 2
#define CRUISE_CONTROL 69 //start
#define DATA_CONTROL 70
#define END_CONTROL 71
